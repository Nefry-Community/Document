#ifndef nefry_h
#define nefry_h

#include <ESP8266WiFi.h>
#include <ESP8266mDNS.h>
#include <ESP8266WebServer.h>
#include <WiFiClient.h>
#include <EEPROM.h>
#include <Adafruit_NeoPixel.h>
#include <ESP8266httpUpdate.h>

#define WIFI_CONF_FORMAT {0, 0, 0, 1}
#define NAME_PREF "nefry-"
#define WIFI_CONF_START 0

class nefry
{
public:
    void nefry_init();
    void nefry_loop();
    bool pushSW_flg;
protected:
	WiFiServer _TelnetServer = WiFiServer(80);
    WiFiClient _Telnet;
    WiFiUDP _Udp;
    Adafruit_NeoPixel _RGBLED;
    ESP8266WebServer _server;
    
private:
	void RGB_LED(char r,char g,char b);
    void RGB_LED(char r,char g,char b,char w);
	void RGB_LED_blink(char r,char g,char b,int wait,int loop);
    void printWiFiConf(void);
    bool loadWiFiConf();
    void saveWiFiConf(void);
    void setDefaultModuleId(char* dst);
    void resetModuleId(void);
    void scanWiFi(void);
    int  waitConnected(void);
    void printIP(void);
    void setupWiFiConf(void);
    void setupWeb_local_Update(void);
    void setupWeb(void);
    String escapeParameter(String param);
    void push_flg();


};

#endif
