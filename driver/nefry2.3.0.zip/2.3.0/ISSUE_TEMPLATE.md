
問題が起こった時のことを教えてください。

if you have a stack dump decode it:
https://github.com/esp8266/Arduino/blob/master/doc/Troubleshooting/stack_dump.md

for better debug messages:
https://github.com/esp8266/Arduino/blob/master/doc/Troubleshooting/debugging.md

----------------------------- Remove above -----------------------------

### 基本情報

#### ハードウエア
Hardware:			?Nefry v2?
Nefry　Core Version:      	?2.1.0?

### 問題点

問題が起こったときどのような状況になったか

### Sketch

```cpp

#include <Arduino.h>

void setup() {

}

void loop() {

}
```

### エラーメッセージ

```
messages here
```


