#pragma once
#warning heap_alloc_caps.h has been renamed to esp_heap_alloc_caps.h. The old header file is deprecated and will be removed in v3.0.
#include "esp_heap_alloc_caps.h"
