#ifndef Nefry_SettingBase_h
#define Nefry_SettingBase_h
typedef void(*FUNC_POINTER)(void); //�֐��|�C���^��typedef
extern FUNC_POINTER fsetup, floop;

//extern Nefry_Write NefryWriteMode;
#endif
