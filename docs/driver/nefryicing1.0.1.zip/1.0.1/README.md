# Arduino core for ESP32 WiFi chip and NefryLibrary
[![Build Status](https://travis-ci.org/Nefry-Community/arduino-esp32.svg?branch=master)](https://travis-ci.org/Nefry-Community/arduino-esp32)

[Arduino core for ESP32 WiFi chip](https://github.com/espressif/arduino-esp32)をベースにして開発しています。

## エラーデコーダー

[EspExceptionDecoder](https://github.com/me-no-dev/EspExceptionDecoder) エラーデコーダはこちらからダウンロードできます。

## ESP32Dev Board PINMAP

![Pin Functions](https://nefry.studio/img/nefrybt_pinmap.png)
