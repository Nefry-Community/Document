#ifndef nefry_h
#define nefry_h

#include <ESP8266WiFi.h>
#include <ESP8266mDNS.h>
#include <ESP8266WebServer.h>
#include <WiFiClient.h>
#include <EEPROM.h>
#include <Adafruit_NeoPixel.h>
#include <ArduinoOTA.h>

#define WIFI_CONF_FORMAT {0, 0, 0, 1}
#define NAME_PREF "nefry-"
#define WIFI_CONF_START 0

class nefry
{
public:
    //OTA();
    void ota_init();
    void ota_loop();
    void RGB_LED(char r,char g,char b);
    void RGB_LED(char r,char g,char b,char w);


protected:
    WiFiServer _TelnetServer = WiFiServer(80);
    WiFiClient _Telnet;
    WiFiUDP _Udp;
    Adafruit_NeoPixel _RGBLED;
    ESP8266WebServer _server;

private:
    void ota_start();
    void printWiFiConf(void);
    bool loadWiFiConf();
    void saveWiFiConf(void);
    void setDefaultModuleId(char* dst);
    void resetModuleId(void);
    void scanWiFi(void);
    int  waitConnected(void);
    void printIP(void);
    void setupWiFiConf(void);
    void setupWebUpdate(void);
    void setupWeb(void);
    void setup_nefryWeb(void);
};

#endif
